const router = require('express').Router();
const mongoose = require('mongoose');
const User = require('../model/User');
const verify = require('./verifyToken');
//const app = express();

// Get all records
router.get('/testList', verify, (req, res) => {
    console.log("This is tutorial 43");
    async function achhar() {
        console.log('inside achhar function');
        //const response = await fetch('https://api.github.com/users').then(res => res.json());
        return "achhar";
    }
    console.log('Before calling achhar');
    const a = achhar();
    console.log('after calling achhar');
    console.log(a)
    console.log('Last line of this js file');
});

module.exports = router;
