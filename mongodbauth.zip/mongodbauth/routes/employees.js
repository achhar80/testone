const router = require('express').Router();
const mongoose = require('mongoose');
const User = require('../model/User');
const verify = require('./verifyToken');
//const app = express();

// Get all records http://localhost:3000/employees/usersList?page=1&limit=2
router.get('/usersList', verify,paginatedResults(User), (req, res) => {
    // User.find({}, (err, users) => {
    //     var userMap = {};

    //     users.forEach((user) => {
    //         userMap[user._id] = user;
    //     });

    //     /*  users.forEach((user, index) => {
    //          userMap += user.name;
    //      }) */

    //     res.send(userMap);
    // });
res.json(res.paginatedResults)
});

function paginatedResults(model) {
    return async (req, res, next) => {

        const page = parseInt(req.query.page)
        const limit = parseInt(req.query.limit)

        const startIndex = (page - 1) * limit
        const endIndex = page * limit

        const results = {}

        if (endIndex < await model.find().count()) {
            results.next = {
                page: page + 1,
                limit: limit
            }

        }

        if (startIndex > 0) {
            results.previous = {
                page: page - 1,
                limit: limit
            }
        }
        try {
            results.results = await model.find().limit(limit).skip(startIndex).exec()
            res.paginatedResults = results
            next()

        } catch (error) {
            res.status(500).json({ message: error.message })
        }
    }
}

router.post('/userUpdate', verify, async (req, res) => {
    // update the document

    const id = req.body.id;
    //console.log("her...." + id);
    const user = await User.findOne({ _id: id });
    if (!user) return res.status(400).send('ID is does not exist');
    //const updateDocument = async (id) => {
    try {
        const result = await User.updateOne({ _id: id }, {
            $set: {
                name: req.body.name
            }
        });
        console.log(result);
        res.send('update successfully!');
    } catch (error) {
        console.log(err);
    }


});
/*
router.get('', (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log(`connected as id ${connection.threadid}`)
        connection.query('SELECT * from employee', (err, rows) => {
            connection.release() //return the connection to pool1

            if (!err) {
                //res.send(rows)
                return res.status(200).json({
                    success: 1,
                    data: rows
                })
            } else {
                //console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: "Database connection error",
                    data: err
                })
            }
        })
    })

});*/

module.exports = router;