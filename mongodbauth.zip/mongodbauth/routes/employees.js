const router = require('express').Router();
const mongoose = require('mongoose');
const User = require('../model/User');
const verify = require('./verifyToken');
//const app = express();

// Get all records
router.get('/usersList', verify, (req, res) => {
    User.find({}, (err, users) => {
        var userMap = {};

        users.forEach((user) => {
            userMap[user._id] = user;
        });

        res.send(userMap);
    });
});

router.post('/userUpdate', verify, async (req, res) => {
    // update the document

    const id = req.body.id;
    //console.log("her...." + id);
    const user = await User.findOne({ _id: id });
    if (!user) return res.status(400).send('ID is does not exist');
    //const updateDocument = async (id) => {
    try {
        const result = await User.updateOne({ _id: id }, {
            $set: {
                name: req.body.name
            }
        });
        console.log(result);
        res.send('update successfully!');
    } catch (error) {
        console.log(err);
    }


});
/*
router.get('', (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log(`connected as id ${connection.threadid}`)
        connection.query('SELECT * from employee', (err, rows) => {
            connection.release() //return the connection to pool1

            if (!err) {
                //res.send(rows)
                return res.status(200).json({
                    success: 1,
                    data: rows
                })
            } else {
                //console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: "Database connection error",
                    data: err
                })
            }
        })
    })

});*/

module.exports = router;