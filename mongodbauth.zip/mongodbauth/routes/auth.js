const router = require('express').Router();
const User = require('../model/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const parser = require("smooth-validator");

const schema = {
    name: 'required|min:5|max:10',
    email: 'required|email|min:5|max:100',
    password: 'required|min:6|max:30',
}

//VALIDATION for login

const schemaLogin = {
    email: 'required|email|min:5|max:100',
    password: 'required|min:6|max:30',
}

router.post('/register', async (req, res) => {
    var validator = parser(schema) //parser returns validator, which can be used on data object
    if (validator(req.body).message != "validation passed") return res.status(400).send(validator(req.body));
    // checking if the user is already in the database
    const emailExist = await User.findOne({ email: req.body.email });
    if (emailExist) return res.status(400).send('Email already exists');
    //hash passwords
    const salt = bcrypt.genSaltSync(10);
    //const salt1 = bcrypt.compareSync
    const hashedpassword = bcrypt.hashSync(req.body.password, salt);

    // res.send('Register');
    const user = new User({
        name: req.body.name,
        email: req.body.email,
        password: hashedpassword
    });
    try {
        const savedUser = await user.save();
        res.send(savedUser);
    } catch (error) {
        res.status(400).send(err);

    }
});
//Login
router.post('/login', async (req, res) => {
    var validator = parser(schemaLogin) //parser returns validator, which can be used on data object
    if (validator(req.body).message != "validation passed") return res.status(400).send(validator(req.body));

    //checking if the email exists
    const user = await User.findOne({ email: req.body.email });
    if (!user) return res.status(400).send('Email is does not exist');
    //comparing password
    //const validPass = bcrypt.compareSync(req.body.password, user.password);
    const validPass = await bcrypt.compare(req.body.password, user.password);
    if (!validPass) return res.status(400).send('Invalid password')

    //create and assign a token
    const token = jwt.sign({ _id: user._id }, process.env.TOKEN_SECRET);
    // res.header('auth-token', token).send(token);
    //res.send(token);
    res.status(201).send({ "status": "success", "message": "Login Success", "token": token })
    // res.send('Logged in!');

})

module.exports = router;