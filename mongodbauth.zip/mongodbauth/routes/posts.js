const router = require('express').Router();
const User = require('../model/User');
const verify = require('./verifyToken');

router.get('/', verify, (req, res) => {
    //res.send(req.user);
    //User.findById({_id: req.user})
    res.json({
        post: {
            title: 'my first post',
            description: 'random data you shouldnot access'
        }
    });
});

module.exports = router;