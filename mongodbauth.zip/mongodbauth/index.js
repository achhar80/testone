const express = require('express');
//import dotenv from 'dotenv'
require('dotenv').config();
const mongoose = require('mongoose');
const app = express();
//import connectDB from './config/connectdb.js'
const connectDB = require('./config/connect');
//import routes
const authRoute = require('./routes/auth');
const postRoute = require('./routes/posts');
const employeeRoute = require('./routes/employees');

const DATABASE_URL = process.env.DATABASE_URL

// Database Connection
connectDB(DATABASE_URL)

//middleware
app.use(express.json());

//Route Middlewares
app.use('/api/user', authRoute);
app.use('/api/posts', postRoute);
app.use('/employees', employeeRoute);

app.listen(3000, () => console.log('server up and running on port 3000' + DATABASE_URL));