require('dotenv').config();
const mysql = require('mysql');
const express = require('express');
const bodyparser = require('body-parser');
const postRoute = require('./routes/posts');
const authRoute = require('./routes/auth');
const employeeRoute = require('./routes/employees');

const app = express();
const port = process.env.APP_PORT

app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());

app.use('/posts', postRoute);
app.use('/employees', employeeRoute); authRoute
app.use('/auth', authRoute);
/* // Get all records
app.get('', (req, res) => {

	pool.getConnection((err, connection) => {
		if (err) throw err
		console.log(`connected as id ${connection.threadid}`)
		connection.query('SELECT * from employee', (err, rows) => {
			connection.release() //return the connection to pool1

			if (!err) {
				res.send(rows)
			} else {
				console.log(err)
			}
		})
	})

})

// Get a record by ID
app.get('/:id', (req, res) => {

	pool.getConnection((err, connection) => {
		if (err) throw err
		console.log(`connected as id ${connection.threadid}`)
		connection.query('SELECT * from employee WHERE EmpID = ?', [req.params.id], (err, rows) => {
			connection.release() //return the connection to pool1

			if (!err) {
				res.send(rows)
			} else {
				console.log(err)
			}
		})
	})

})

// Delete record
app.delete('/:id', (req, res) => {

	pool.getConnection((err, connection) => {
		if (err) throw err
		console.log('connected as id ${connection.threadid}')
		connection.query('DELETE from employee WHERE EmpID = ?', [req.params.id], (err, rows) => {
			connection.release() //return the connection to pool1

			if (!err) {
				res.send(`Beer with the Record ID: ${[req.params.id]} has been removed`)
			} else {
				console.log(err)
			}
		})
	})

})


// insert a  records
app.post('', (req, res) => {

	pool.getConnection((err, connection) => {
		if (err) throw err
		console.log('connected as id ${connection.threadid}')

		const params = req.body;

		connection.query('INSERT INTO employee SET ?', params, (err, rows) => {
			connection.release() //return the connection to pool1

			if (!err) {
				res.send(`Beer with the Record Nane: ${params.Name} has been added.`)
			} else {
				console.log(err)
			}
		})

		console.log(req.body)
	})

})

// Update a  records
app.put('', (req, res) => {

	pool.getConnection((err, connection) => {
		if (err) throw err
		console.log('connected as id ${connection.threadid}')

		const { EmpID, Name, EmpCode, Salary } = req.body;

		connection.query('UPDATE employee SET Name = ?, EmpCode = ?, Salary = ? WHERE EmpID = ?', [Name, EmpCode, Salary, EmpID], (err, rows) => {
			connection.release() //return the connection to pool1

			if (!err) {
				res.send(`Beer with the Record Nane: has been updated.`)
			} else {
				console.log(err)
			}
		})

		console.log(req.body)
	})

})
 */
//Listen on environment port 5000
app.listen(port, () => console.log(`Listen on port ${port}`))