const router = require('express').Router();
const mysql = require('mysql');
const pool = require("../config/database");
const jwt = require('jsonwebtoken');
//const bcrypt = require('bcrypt');

//VALIDATION for registration
const parser = require("smooth-validator");

const schema = {
    username: 'required|min:5|max:10',
    email: 'required|email|min:5|max:100',
    password: 'required|min:6|max:30',
}

//VALIDATION for login

const schemaLogin = {
    email: 'required|email|min:5|max:100',
    password: 'required|min:6|max:30',
}


// insert a  records
router.post('/register', (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log('connected as id ${connection.threadid}')

        //Lets validate the data before we make user

        // Joi.validation(req.body, schema);

        var validator = parser(schema) //parser returns validator, which can be used on data object

        // res.send(validator(req.body));
        //const { error } = validator(req.body);
        //console.log(validator(req.body).message);
        if (validator(req.body).message != "validation passed") return res.status(400).send(validator(req.body));

        //checking if user already in database
        //const salt = bcrypt.genSaltSync(10);
        //req.body.password = bcrypt.hashSync(req.body.password, salt);
        connection.query('SELECT * from users WHERE email = ?', [req.body.email], (err, rows) => {
            // connection.release() //return the connection to pool1

            if (!err) {
                //console.log(rows.length);
                if (rows.length) {
                    return res.status(400).send("Email already Exist");
                } else {
                    //hash
                    const params = req.body;
                    connection.query('INSERT INTO users SET ?', params, (err, rows) => {
                        connection.release() //return the connection to pool1

                        if (!err) {
                            res.send(`Beer with the Record Nane: ${params.username} has been added.`)
                        } else {
                            console.log(err)
                        }
                    })
                }
                // res.send(rows)
            } else {
                console.log(err)
            }
        })
        console.log(req.body)
    })

})
// insert a  records
router.post('/login', async (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log('connected as id ${connection.threadid}')

        //Lets validate the data before we make user

        // Joi.validation(req.body, schema);

        var validator = parser(schemaLogin) //parser returns validator, which can be used on data object

        // res.send(validator(req.body));
        //const { error } = validator(req.body);
        //console.log(validator(req.body).message);
        if (validator(req.body).message != "validation passed") return res.status(400).send(validator(req.body));

        //checking if user already in database
        connection.query('SELECT * from users WHERE email = ?', [req.body.email], async (err, rows) => {
            connection.release() //return the connection to pool1

            if (!err) {
                //console.log(rows.length);
                if (rows.length) {
                    //hash
                    // console.log(rows[0].password);
                    /*
                                        const salt = await bcrypt.genSaltSync(10);
                                        req.body.password = await bcrypt.hashSync(req.body.password, salt);
                                        //console.log('hash password >> ' + req.body.password + '<<database pass >>' + rows[0].password);
                                        const validPass = await bcrypt.compare(req.body.password, rows[0].password);
                                        if (!validPass) return res.status(400).send("password is not matching");
                    
                                        res.header('auth-token', token).send(token);*/

                    if (req.body.password == rows[0].password) {
                        //console.log("password is matching");
                        //create and assign a token
                        const token = jwt.sign(rows[0].id, 'achharkumar');
                        // const token = jwt.sign(rows[0].id, proecess.env.TOKEN_SECRET);
                        //console.log(token);
                        res.header('auth-token', token).send(token);
                    } else {
                        //console.log("password is not matching");
                        return res.status(400).send("password is not matching");
                    }
                    /*  const params = req.body;
                     connection.query('INSERT INTO users SET ?', params, (err, rows) => {
                         connection.release() //return the connection to pool1
 
                         if (!err) {
                             res.send(`Beer with the Record Nane: ${params.username} has been added.`)
                         } else {
                             console.log(err)
                         }
                     }) */
                } else {
                    return res.status(400).send("Email doesn't Exist");
                }
                // res.send(rows)
            } else {
                console.log(err)
            }
        })


        console.log(req.body)
    })

})

module.exports = router;