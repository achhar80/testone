const router = require('express').Router();
const pool = require("../config/database");
const mysql = require('mysql');

// Get all records
router.get('', (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log(`connected as id ${connection.threadid}`)
        connection.query('SELECT * from employee', (err, rows) => {
            connection.release() //return the connection to pool1

            if (!err) {
                //res.send(rows)
                return res.status(200).json({
                    success: 1,
                    data: rows
                })
            } else {
                //console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: "Database connection error",
                    data: err
                })
            }
        })
    })

});

// Get a record by ID
router.get('/:id', (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log(`connected as id ${connection.threadid}`)
        connection.query('SELECT * from employee WHERE EmpID = ?', [req.params.id], (err, rows) => {
            connection.release() //return the connection to pool1

            if (!err) {
                res.send(rows)
            } else {
                console.log(err)
            }
        })
    })

})

// Delete record
router.delete('/:id', (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log('connected as id ${connection.threadid}')
        connection.query('DELETE from employee WHERE EmpID = ?', [req.params.id], (err, rows) => {
            connection.release() //return the connection to pool1

            if (!err) {
                res.send(`Beer with the Record ID: ${[req.params.id]} has been removed`)
            } else {
                console.log(err)
            }
        })
    })

})


// insert a  records
router.post('', (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log('connected as id ${connection.threadid}')

        const params = req.body;

        connection.query('INSERT INTO employee SET ?', params, (err, rows) => {
            connection.release() //return the connection to pool1

            if (!err) {
                res.send(`Beer with the Record Nane: ${params.Name} has been added.`)
            } else {
                console.log(err)
            }
        })

        console.log(req.body)
    })

})

// Update a  records
router.put('', (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) throw err
        console.log('connected as id ${connection.threadid}')

        const { EmpID, Name, EmpCode, Salary } = req.body;

        connection.query('UPDATE employee SET Name = ?, EmpCode = ?, Salary = ? WHERE EmpID = ?', [Name, EmpCode, Salary, EmpID], (err, rows) => {
            connection.release() //return the connection to pool1

            if (!err) {
                res.send(`Beer with the Record Nane: has been updated.`)
            } else {
                console.log(err)
            }
        })

        console.log(req.body)
    })

})

module.exports = router;