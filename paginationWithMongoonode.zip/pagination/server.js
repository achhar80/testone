const express = require('express')
const app = express()
const mongoose = require('mongoose')
const User = require('./users')
const connectDB = require('./connect')

//mongoose.connect('mongodb://localhost:27017')
connectDB('mongodb://localhost:27017')
const db = mongoose.connection
/* db.once('open', async () => {
    if (await User.countDocuments().exec() > 0)
        console.log('There is not any user added')
}) */

app.get('/users', paginatedResults(User), (req, res) => {
    res.json(res.paginatedResults)
})

function paginatedResults(model) {
    return async (req, res, next) => {

        const page = parseInt(req.query.page)
        const limit = parseInt(req.query.limit)

        const startIndex = (page - 1) * limit
        const endIndex = page * limit

        const results = {}

        if (endIndex < await model.find().count()) {
            results.next = {
                page: page + 1,
                limit: limit
            }

        }

        if (startIndex > 0) {
            results.previous = {
                page: page - 1,
                limit: limit
            }
        }
        try {
            results.results = await model.find().limit(limit).skip(startIndex).exec()
            res.paginatedResults = results
            next()

        } catch (error) {
            res.status(500).json({ message: error.message })
        }
    }
}
app.listen(3100)